const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];

const workoutPlans = {
  starter: {
    title: 'Full-body starter', duration: 12,
    intro: 'A gentle introduction. Move at a comfortable pace and rest whenever you need.',
    exercises: [
      ['Warm-up march', '2 minutes', 'March gently in place; keep your shoulders relaxed.'],
      ['Chair sit-to-stand', '2 sets of 6–8', 'Use a sturdy chair and move slowly. Skip if uncomfortable.'],
      ['Wall push-ups', '2 sets of 6–8', 'Place hands on a wall and keep your body in a comfortable line.'],
      ['Standing calf raises', '2 sets of 8–10', 'Hold a stable surface for balance if needed.'],
      ['Easy cool-down', '2 minutes', 'Slow your pace and take calm, natural breaths.']
    ]
  },
  walk: {
    title: 'Indoor walking', duration: 15,
    intro: 'A low-impact movement break. Keep the pace easy enough to speak comfortably.',
    exercises: [
      ['Easy march in place', '3 minutes', 'Start slowly and find a comfortable rhythm.'],
      ['March with relaxed arm swings', '4 minutes', 'Let your arms swing naturally if comfortable.'],
      ['Side steps', '3 minutes', 'Step gently side to side; use a smaller range if needed.'],
      ['Easy march', '3 minutes', 'Return to a relaxed pace.'],
      ['Cool-down', '2 minutes', 'Slow down gradually and relax your shoulders.']
    ]
  },
  strength: {
    title: 'Bodyweight basics', duration: 18,
    intro: 'A beginner-friendly strength session. Rest between sets and choose comfortable variations.',
    exercises: [
      ['Gentle warm-up', '3 minutes', 'March in place and move your shoulders gently.'],
      ['Chair sit-to-stand', '2 sets of 8', 'Use a stable chair and keep the movement controlled.'],
      ['Wall push-ups', '2 sets of 8', 'Move closer to the wall for an easier variation.'],
      ['Glute bridge or standing hip extension', '2 sets of 8', 'Choose the variation that feels comfortable and safe.'],
      ['Bird-dog or standing reach', '2 sets of 6 each side', 'Move slowly and focus on balance, not speed.'],
      ['Cool-down', '2 minutes', 'Take a gentle walk and relax.']
    ]
  }
};

const STORAGE_KEY = 'fitlife-dashboard-v1';
const todayKey = new Date().toLocaleDateString('en-CA');
const defaultState = () => ({
  date: todayKey,
  habits: { move: false, water: false, food: false, rest: false },
  water: 0, minutes: 0, mood: '', note: ''
});
let state = loadState();
let activeWorkout = null;

function loadState() {
  try {
    const saved = JSON.parse(localStorage.getItem(STORAGE_KEY));
    if (saved && saved.date === todayKey) {
      return { ...defaultState(), ...saved, habits: { ...defaultState().habits, ...(saved.habits || {}) } };
    }
  } catch (error) {
    console.warn('Could not load saved FitLife data:', error);
  }
  return defaultState();
}
function saveState() {
  try { localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); }
  catch (error) { console.warn('Could not save FitLife data:', error); }
}
function habitTotal() { return Object.values(state.habits).filter(Boolean).length; }
function renderDashboard() {
  const count = habitTotal();
  $('#habitCount').textContent = count;
  $('#habitBadge').textContent = `${count}/4`;
  $('#habitProgress').style.width = `${count / 4 * 100}%`;
  $('#habitMessage').textContent = count === 4 ? 'All four habits checked off — great work!' : count === 0 ? 'Start with one small win' : `${4 - count} more ${4 - count === 1 ? 'habit' : 'habits'} if you want`;
  $('#minutesCount').textContent = state.minutes;
  $('#waterCount').textContent = state.water;
  $('#waterDrops').textContent = Array.from({length: 8}, (_, i) => i < state.water ? '●' : '○').join(' ');
  $('#bigProgress').textContent = `${Math.round(count / 4 * 100)}%`;
  $('#bigProgressBar').style.width = `${count / 4 * 100}%`;
  $('#summaryHabits').textContent = `${count}/4`;
  $('#summaryMinutes').textContent = state.minutes;
  $('#summaryWater').textContent = state.water;
  $$('[data-habit]').forEach(input => {
    input.checked = Boolean(state.habits[input.dataset.habit]);
    input.closest('.habit-item').classList.toggle('done', input.checked);
  });
  $$('[data-mood]').forEach(button => button.setAttribute('aria-pressed', String(button.dataset.mood === state.mood)));
  $('#reflectionNote').value = state.note || '';
  const moodMessages = {
    low: 'A gentle day is still a day in your journey. Rest is part of progress.',
    okay: 'Steady is good. One small, kind choice is enough for now.',
    good: 'Enjoy that energy, and remember that rest matters on every kind of day.'
  };
  $('#moodMessage').textContent = moodMessages[state.mood] || 'Every kind of day belongs in your journey.';
}
function showSection(sectionId) {
  const allowed = ['home', 'workouts', 'nutrition', 'habits', 'progress'];
  const target = allowed.includes(sectionId) ? sectionId : 'home';
  $$('.page-section').forEach(section => section.classList.toggle('active', section.id === target));
  $$('.nav-link').forEach(link => link.classList.toggle('active', link.dataset.section === (target === 'progress' ? 'habits' : target)));
  $('#pageName').textContent = ({home:'Dashboard',workouts:'Workouts',nutrition:'Nutrition',habits:'Daily habits',progress:'Progress tracker'})[target];
  if (target === 'habits') {
    // Habits live on the dashboard; the tracker has its own reflection view.
    $('#home').classList.remove('active');
    $('#progress').classList.add('active');
    $('#pageName').textContent = 'Progress tracker';
  }
  history.replaceState(null, '', `#${target}`);
  $('.app-shell').classList.remove('menu-open');
  window.scrollTo({top: 0, behavior: 'smooth'});
}
function openWorkout(id) {
  const plan = workoutPlans[id];
  if (!plan) return;
  activeWorkout = id;
  $('#modalTitle').textContent = plan.title;
  $('#modalIntro').textContent = plan.intro;
  $('#modalDuration').textContent = `◷ ${plan.duration} minutes`;
  $('#exerciseList').innerHTML = plan.exercises.map(([name, amount, detail]) =>
    `<li><strong>${escapeHTML(name)} <span style="font-weight:500;color:#72924e">· ${escapeHTML(amount)}</span></strong><span>${escapeHTML(detail)}</span></li>`
  ).join('');
  $('#modalFeedback').textContent = '';
  $('#completeWorkout').disabled = false;
  $('#completeWorkout').textContent = '✓ Mark as completed';
  $('#workoutModal').hidden = false;
  document.body.style.overflow = 'hidden';
  $('#closeModal').focus();
}
function closeWorkout() {
  $('#workoutModal').hidden = true;
  document.body.style.overflow = '';
  activeWorkout = null;
}
function escapeHTML(value) {
  return String(value).replace(/[&<>"']/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
}

function routeFromHash() {
  const hash = location.hash.slice(1);
  if (['home','workouts','nutrition','progress'].includes(hash)) {
    $$('.page-section').forEach(section => section.classList.toggle('active', section.id === hash));
    $$('.nav-link').forEach(link => link.classList.toggle('active', link.dataset.section === hash));
    $('#pageName').textContent = ({home:'Dashboard',workouts:'Workouts',nutrition:'Nutrition',progress:'Progress tracker'})[hash];
  } else {
    $$('.page-section').forEach(section => section.classList.toggle('active', section.id === 'home'));
  }
}

document.addEventListener('click', event => {
  const nav = event.target.closest('[data-section]');
  if (nav) {
    event.preventDefault();
    showSection(nav.dataset.section);
  }
  const workoutButton = event.target.closest('[data-start-workout]');
  if (workoutButton) openWorkout(workoutButton.dataset.startWorkout);
});
$$('[data-habit]').forEach(input => input.addEventListener('change', () => {
  state.habits[input.dataset.habit] = input.checked;
  saveState(); renderDashboard();
}));
$('#waterPlus').addEventListener('click', () => { state.water = Math.min(20, state.water + 1); saveState(); renderDashboard(); });
$('#waterMinus').addEventListener('click', () => { state.water = Math.max(0, state.water - 1); saveState(); renderDashboard(); });
$$('.filter-btn').forEach(button => button.addEventListener('click', () => {
  $$('.filter-btn').forEach(item => item.classList.toggle('active', item === button));
  $$('.workout-card').forEach(card => {
    const filter = button.dataset.filter;
    card.hidden = filter !== 'all' && card.dataset.category !== filter;
  });
}));
$('#menuToggle').addEventListener('click', () => $('.app-shell').classList.toggle('menu-open'));
$('#closeModal').addEventListener('click', closeWorkout);
$('#cancelWorkout').addEventListener('click', closeWorkout);
$('#workoutModal').addEventListener('click', event => { if (event.target === $('#workoutModal')) closeWorkout(); });
document.addEventListener('keydown', event => { if (event.key === 'Escape' && !$('#workoutModal').hidden) closeWorkout(); });
$('#completeWorkout').addEventListener('click', () => {
  if (!activeWorkout) return;
  const plan = workoutPlans[activeWorkout];
  state.minutes += plan.duration;
  state.habits.move = true;
  saveState(); renderDashboard();
  $('#modalFeedback').textContent = `Nice work — ${plan.duration} minutes added to today's dashboard.`;
  $('#completeWorkout').disabled = true;
  $('#completeWorkout').textContent = '✓ Completed';
});
$$('[data-mood]').forEach(button => button.addEventListener('click', () => {
  state.mood = button.dataset.mood; saveState(); renderDashboard();
}));
$('#saveNote').addEventListener('click', () => {
  state.note = $('#reflectionNote').value.slice(0, 1000);
  saveState();
  $('#noteStatus').textContent = 'Reflection saved on this device.';
  window.setTimeout(() => { $('#noteStatus').textContent = ''; }, 2500);
});
$('#todayDate').textContent = new Intl.DateTimeFormat(undefined, {weekday:'short', month:'short', day:'numeric'}).format(new Date());
routeFromHash();
renderDashboard();
