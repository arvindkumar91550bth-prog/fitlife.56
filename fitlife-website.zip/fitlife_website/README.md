# FitLife — Free Fitness Website

A responsive, beginner-friendly fitness dashboard made with plain HTML, CSS, and JavaScript.

## Features
- Responsive dashboard for desktop and mobile
- Workout library with category filters
- Workout details modal and completion logging
- Daily habits checklist
- Water check-in counter
- General balanced-eating tips and meal ideas
- Daily reflection and mood check-in
- Saves today's dashboard data in the browser using `localStorage`
- No framework, account, API key, or paid service required

## Run it locally
1. Download and unzip `fitlife-website.zip`.
2. Open the `fitlife_website` folder.
3. Double-click `index.html` to open it in your browser.

For the easiest editing experience, open the folder in Visual Studio Code and use the free **Live Server** extension, or run a local server from the folder:
- Python: `python -m http.server 8000`
- Then visit `http://localhost:8000`

## Publish for free
### GitHub Pages
1. Create a free GitHub account and a new repository.
2. Upload `index.html`, `style.css`, and `script.js` to the repository's root.
3. In repository Settings → Pages, choose deployment from the `main` branch and `/ (root)`.
4. Save and wait for GitHub to provide the published website URL.

### Netlify
You can also use Netlify's free options to deploy the folder or repository. Check the service's current plan and terms before publishing.

## Notes
- The dashboard stores data only in this browser on this device. Clearing browser data can remove it; another browser/device won't automatically share it.
- The Google Fonts import is optional. If offline, the page uses fallback fonts.
- Workout and nutrition content is general educational guidance, not personalised medical advice. Adjust activity to your comfort and consult a qualified professional when needed.
